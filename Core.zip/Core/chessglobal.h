#ifndef CHESSGLOBAL_H
#define CHESSGLOBAL_H

#include <cstring>
#include <iostream>
#include <stack>
#include <sys/ioctl.h>
#include <sys/types.h>
#include <termios.h>
#include <unistd.h>
#include <vector>

#endif
