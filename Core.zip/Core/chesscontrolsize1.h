#ifndef CHESSCONTROL1_H
#define CHESSCONTROL1_H

#include "chesscontrol.h"

class chessControlSize1 : public chessControl {
public:
    chessControlSize1( char name = 'n' );
};

#endif