#ifndef CHESSCONTROL2_H
#define CHESSCONTROL2_H

#include "chesscontrol.h"

class chessControlSize2 : public chessControl {
public:
    chessControlSize2( char name = 'n' );
};

#endif
